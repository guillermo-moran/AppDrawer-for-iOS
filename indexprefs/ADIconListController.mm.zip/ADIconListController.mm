#import <Preferences/Preferences.h>
#import <UIKit/UITableViewCell+Private.h>

//#import <Preferences/PSViewController.h>

// Borrowed code from Chronic Dev's Animate. Sorry guys :)

// #define PREFS_FILE_PATH @"/var/mobile/Library/Preferences/com.gmoran.index.plist"
#define ICON_PREFS_PATH @"/Library/Application Support/AppDrawer/icon.plist"

@interface ADIconListController : PSViewController <UITableViewDelegate, UITableViewDataSource> {
    //an array of folders for possible icons.
    NSMutableArray *icons;
    
    //the settings Dictionary
    NSMutableDictionary *plistDictionary;
    
    //The identifier of the currently selected logo.
    NSString *currentlySelected;
    
    //do I really need to explain this one?
    UITableView *_iconTable;
    //UIBarButtonItem *previewButton;
    
}

+ (void) load;

- (id) initForContentSize:(CGSize)size;
- (id) view;
- (id) navigationTitle;
- (void) themesChanged;

- (NSInteger) numberOfSectionsInTableView:(UITableView *)tableView;
- (id) tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section;
- (NSInteger) tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section;
- (id) tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath;
- (void) tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath;
- (void) tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath;
- (UITableViewCellEditingStyle) tableView:(UITableView *)tableView editingStyleForRowAtIndexPath:(NSIndexPath *)indexPath;
- (BOOL) tableView:(UITableView *)tableView shouldIndentWhileEditingRowAtIndexPath:(NSIndexPath *)indexPath;
- (BOOL) tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath;
- (UIImage *)imageWithImage:(UIImage *)image scaledToSize:(CGSize)newSize;

@end

@implementation ADIconListController

//Our title...
- (NSString*) title {
    return @"Homescreen Icon";
}

//just to be safe. Return the tableview if someone asks.
- (UIView*)view {
    return _iconTable;
}


+ (void)load {
    //every good party needs a pool!
    @autoreleasepool {}
}

//The bulk of the initiation done here.
- (id) initForContentSize:(CGSize)size {
    
    if ((self = [super init]) != nil) {
        
        icons = [[NSMutableArray alloc] init];
        
        if ([[NSFileManager defaultManager] fileExistsAtPath:ICON_PREFS_PATH]) {
            //NSDictionary *plistDictionary = [[NSDictionary dictionaryWithContentsOfFile:@"/Library/BootLogos/org.chronic-dev.animate.plist"] retain];
            //not using a dict atm... seems to be saving problems.
            
            NSError *error;
            
            currentlySelected = [[[NSString alloc] initWithString: [[NSArray arrayWithContentsOfFile:ICON_PREFS_PATH] objectAtIndex:0]] retain];
        
        }
        
        if(currentlySelected == nil)
            
            currentlySelected = @"Default Icon";
        
        [self reloadPossibleLogos];
        
        _iconTable = [[UITableView alloc] initWithFrame: (CGRect){{0,0}, size} style:UITableViewStyleGrouped];
        [_iconTable setDataSource:self];
        [_iconTable setDelegate:self];
        
        if ([self respondsToSelector:@selector(setView:)]) {
            
            [self setView:_iconTable];
            
        }
    }
    return self;
}



-(void)reloadPossibleLogos {
    
    [icons removeAllObjects];
    
    id file = nil;
    
    NSDirectoryEnumerator *enumerator = [[NSFileManager defaultManager]
                                         enumeratorAtPath:@"/Library/Application Support/AppDrawer"];
    
    while ((file = [enumerator nextObject]))
    {
        
        BOOL isDirectory = NO;
        
        [[NSFileManager defaultManager] fileExistsAtPath:[NSString stringWithFormat:@"%@/%@", @"/Library/Application Support/AppDrawer", file] isDirectory:&isDirectory];
        
        if (isDirectory && ![file isEqualToString:@"Default Icon"]) {
            [icons addObject:file];
        }
        
    }
    
}


//something changed, not sure what.. but lets reload the data anyways.
- (void) reloadSpecifiers {
    
    [_iconTable reloadData];
}

//Headers are always a nice touch.

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section{
    if(section == 0)
        return @"Default Icons";
    else
        return @"Installed Icons";
}

- (void)viewWillAppear:(BOOL)animated {
    
    [self reloadPossibleLogos];
    
    if ([currentlySelected isEqualToString:@"Default Icon"]) {
        
        //self.navigationItem.rightBarButtonItem = nil;
        
    }
    
    else {
        
        //self.navigationItem.rightBarButtonItem = previewButton;
    }
    
    [_iconTable reloadData];
}

- (UIImage *)imageWithImage:(UIImage *)image scaledToSize:(CGSize)newSize {
    
    UIGraphicsBeginImageContextWithOptions(newSize, NO, 0.0);
    [image drawInRect:CGRectMake(0, 0, newSize.width, newSize.height)];
    UIImage *newImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return newImage;
}

- (void)viewDidUnload {
    
    [super viewDidUnload];
}


#pragma mark - Table view data source

/*
 *All of this should be very self explanatory..
 */

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    if ([icons count] > 0) {
        return 2;
    }
    
    else {
        return 1;
    }
    
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (section == 0) {
        
        return 1;
    }
    
    else
        return [icons count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString *CellIdentifier = @"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    
    if (cell == nil) {
        
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    }
    
    cell.accessoryType = UITableViewCellAccessoryNone;
    
    if (indexPath.section == 0) {
        
        if(indexPath.row == 0){
            
            cell.textLabel.text = @"Default Icon";
            
            UIImage* icon = [UIImage imageWithContentsOfFile:[NSString stringWithFormat:@"/Library/Application Support/AppDrawer/Default Icon/AppDrawer.png"]];
            
            UIImage* previewIcon = [self imageWithImage:icon scaledToSize:CGSizeMake(30,30)];
            
            cell.imageView.image = previewIcon;
            
            if([currentlySelected isEqualToString:@"Default Icon"]) {
                
                cell.accessoryType = UITableViewCellAccessoryCheckmark;
                
            }
            
        }
        
    }
    
    else if (indexPath.section == 1) {
        
        cell.textLabel.text = [icons objectAtIndex:indexPath.row];
        
        UIImage* icon = [UIImage imageWithContentsOfFile:[NSString stringWithFormat:@"/Library/Application Support/AppDrawer/%@/AppDrawer.png", [icons objectAtIndex:indexPath.row]]];
        
        UIImage* previewIcon = [self imageWithImage:icon scaledToSize:CGSizeMake(30,30)];
        
        cell.imageView.image = previewIcon;
        
        if ([cell.textLabel.text isEqualToString:currentlySelected]) {
            
            cell.accessoryType = UITableViewCellAccessoryCheckmark;
        }
    }
    
    return cell;
}

- (NSString *)tableView:(UITableView *)tableView titleForFooterInSection:(NSInteger)section {
    
    if(section == 1 || [icons count] <= 0) {
        
        return @"AppDrawer © 2015 Guillermo Morán";
    }
    
    return nil;
}


#pragma mark - Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    if (indexPath.section == 0) {
        
        if (indexPath.row == 0) {
            
            currentlySelected = @"Default Icon";
            
        }
        
    }
    
    else {
        
        currentlySelected = [icons objectAtIndex:indexPath.row];
    }
    
    NSError *error = nil;
    
    NSArray* iconArray = @[currentlySelected];
    
    
    
    if (![iconArray writeToFile:ICON_PREFS_PATH atomically:YES]) {
        
        UIAlertView *errorAlert = [[UIAlertView alloc] initWithTitle:@"Error" message:@"An error occurred while saving your settings. This is probably a permissions problem." delegate:nil cancelButtonTitle:@"I will notify @fr0st" otherButtonTitles:nil];
        
        [errorAlert show];
        [errorAlert release];
    }
    
    [_iconTable reloadData];
    
}

@end